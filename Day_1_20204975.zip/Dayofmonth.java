//EX5
import java.util.Scanner;

public class Dayofmonth {
	public static void main(String[] args) {
		int month;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter your month you want: ");
		month = scanner.nextInt();
		switch (month) {
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				System.out.println("Thang " + month + " has 31 days.");
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				System.out.println("Thang " + month + " has 30 days.");
				break;
			case 2:
				int year;
				System.out.println("Enter your year: ");
				year = scanner.nextInt();
				if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0)) {
					System.out.println("Thang " + month + " nam " + year + " has 29 days.");
				} else {
					System.out.println("Thang " + month + " nam " + year + " has 28 days.");
				}
				break;
			default:
				System.out.println("Error");
			}
	}

}