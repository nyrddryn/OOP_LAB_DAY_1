//EX2
import java.util.Scanner;
public class InputFromKeyboard{
	public static void main(String[]  args){
		Scanner sc = new Scanner(System.in);
		System.out.println("What's your name?");
		String name = sc.nextLine();
		System.out.println("My name is: " + name);
	}
}